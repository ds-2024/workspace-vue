<template>
    <div>이름을 작성하세요 : 윤다솜
        <br><br>
        vue-myclass 프로젝트를 생성하고 사용한 명령어를 작성하세요 : vue create vue-myclass
        <br><br>
        라우터를 vue-myclass에 추가하고 사용한 명령어를 작성하세요 : vue add router-link
        <br><br>
        axios를 vue-myclass에 추가하고 사용한 명령어를 작성하세요 : import axios from 'axios';

    </div>
</template>


<script>
export default {
    name: "MainView",
    components: {},
    data() {
        return {};
    },
    methods: {},
    created(){}
};
</script>


<style></style>